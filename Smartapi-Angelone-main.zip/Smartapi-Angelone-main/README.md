This Python script interacts with Angel One's API to place orders, set a Stoploss, and implement a trailing Stoploss. It is specific for a telegram group which provides options trading. Feel free to modify as per your liking.

Features Order Placement: Place orders on Angel One. Stoploss: Set a Stoploss order. Trailing Stoploss: Implement a trailing Stoploss functionality. Telegram Integration: Fetch trading instructions from a Telegram group.

Requirements Python 3.x Angel One API credentials Telegram API credentials Required Python libraries (see requirements.txt)

*** FELL FREE TO MODIFY THE TRAILING SL CODE AND ADD YOUR API KEY AND OTHER DETAILS FOR EASY TRADING
